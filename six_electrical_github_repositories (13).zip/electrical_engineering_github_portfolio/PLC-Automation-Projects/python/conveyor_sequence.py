"""Small, runnable conveyor sequence demonstrator."""
from enum import Enum, auto

class State(Enum):
    IDLE = auto()
    RUNNING = auto()
    STOPPED_AT_SENSOR = auto()
    FAULT = auto()

def scan(state, start=False, stop=False, part_at_sensor=False, overload=False):
    if overload:
        return State.FAULT
    if stop:
        return State.IDLE
    if state == State.FAULT:
        return State.FAULT
    if part_at_sensor:
        return State.STOPPED_AT_SENSOR
    if start and state in (State.IDLE, State.STOPPED_AT_SENSOR):
        return State.RUNNING
    return state

if __name__ == "__main__":
    state = State.IDLE
    events = [
        {"start": True},
        {},
        {"part_at_sensor": True},
        {"start": True},
        {"overload": True},
    ]
    for event in events:
        state = scan(state, **event)
        print(f"Inputs={event!s:35} -> {state.name}")
