# PLC Automation Projects

A beginner-to-intermediate collection of industrial automation examples. The ladder-logic files are vendor-neutral teaching examples; they are not validated for direct deployment on machinery.

## Contents
- `ladder_logic/start_stop_seal_in.txt` — motor start/stop with seal-in logic
- `ladder_logic/tank_level_control.txt` — two-level tank pump control
- `python/conveyor_sequence.py` — runnable conveyor sequence simulation
- `docs/io_list.csv` — example digital and analog I/O list

## Run
```bash
python python/conveyor_sequence.py
```

## Safety
Use proper risk assessment, safety relays/PLC, emergency-stop circuits, overload protection and machine-specific validation. A software example is not a safety-rated control design.
