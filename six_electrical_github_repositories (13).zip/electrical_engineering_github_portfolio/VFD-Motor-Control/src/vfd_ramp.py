"""Generate a linear VFD frequency ramp."""
def ramp(start_hz: float, target_hz: float, ramp_seconds: float, step_seconds: float = 1.0):
    if ramp_seconds <= 0 or step_seconds <= 0:
        raise ValueError("Ramp and step durations must be positive")
    steps = int(ramp_seconds / step_seconds)
    if steps == 0:
        return [target_hz]
    return [round(start_hz + (target_hz-start_hz)*i/steps, 2)
            for i in range(steps+1)]

def motor_sync_speed(frequency_hz: float, poles: int) -> float:
    if frequency_hz < 0 or poles <= 0 or poles % 2:
        raise ValueError("Frequency must be non-negative and pole count positive/even")
    return 120 * frequency_hz / poles

if __name__ == "__main__":
    values = ramp(0, 50, 10, 2)
    print("Frequency ramp (Hz):", values)
    print("4-pole synchronous speed at 50 Hz:", motor_sync_speed(50, 4), "rpm")
