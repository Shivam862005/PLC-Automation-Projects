# VFD Motor Control

A small variable-frequency-drive (VFD) learning project covering speed references, linear acceleration/deceleration ramps and basic commissioning checks.

## Run
```bash
python src/vfd_ramp.py
```

## Important
This is a mathematical demonstrator, not a drive parameter file. Actual parameters depend on the motor nameplate, drive model, application and manufacturer manual. Never copy generic values into a live drive.
