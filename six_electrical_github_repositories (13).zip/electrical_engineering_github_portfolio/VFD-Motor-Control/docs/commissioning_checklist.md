# Generic VFD Commissioning Checklist

- [ ] Confirm drive model and read its official manual.
- [ ] Verify supply voltage, protective earth and upstream protection.
- [ ] Record motor nameplate voltage, current, frequency, power and speed.
- [ ] Verify motor wiring and insulation using approved procedures.
- [ ] Confirm control mode and command source.
- [ ] Confirm speed reference source and minimum/maximum limits.
- [ ] Set motor data and application-specific ramp values per manufacturer guidance.
- [ ] Test direction at a safe, controlled condition.
- [ ] Verify stop behavior, interlocks and emergency-stop architecture.
- [ ] Record final approved settings and test results.

This checklist is a reminder only; follow site procedures and qualified-person requirements.
