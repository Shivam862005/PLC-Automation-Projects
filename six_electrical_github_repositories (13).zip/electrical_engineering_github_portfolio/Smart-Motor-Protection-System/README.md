# Smart Motor Protection System

A Python simulation of a motor-protection controller with dry-run, overload and leakage-current trip logic. It demonstrates monitoring and event logging; it does not replace certified protection relays or an engineered electrical installation.

## Features
- Configurable current, leakage and dry-run thresholds
- Trip-reason reporting
- CSV event log
- Unit tests

## Run
```bash
python src/motor_guard.py
python -m unittest discover -s tests
```
