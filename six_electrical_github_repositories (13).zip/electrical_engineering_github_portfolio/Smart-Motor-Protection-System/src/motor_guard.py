"""Educational motor protection decision logic."""
from dataclasses import dataclass
from datetime import datetime, timezone
import csv

@dataclass
class Limits:
    max_current_a: float = 12.0
    max_leakage_ma: float = 30.0
    min_running_current_a: float = 1.0

def evaluate(current_a: float, leakage_ma: float, pump_expected_to_run: bool,
             limits: Limits = Limits()):
    reasons = []
    if current_a > limits.max_current_a:
        reasons.append("OVERLOAD")
    if leakage_ma > limits.max_leakage_ma:
        reasons.append("LEAKAGE_THRESHOLD_EXCEEDED")
    if pump_expected_to_run and current_a < limits.min_running_current_a:
        reasons.append("POSSIBLE_DRY_RUN_OR_NO_LOAD")
    return {"trip": bool(reasons), "reasons": reasons}

def log_event(path, measurements, result):
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["timestamp_utc", "current_a", "leakage_ma", "trip", "reasons"])
        writer.writerow([datetime.now(timezone.utc).isoformat(),
                         measurements["current_a"], measurements["leakage_ma"],
                         result["trip"], ";".join(result["reasons"])])

if __name__ == "__main__":
    sample = {"current_a": 0.4, "leakage_ma": 8.0}
    result = evaluate(sample["current_a"], sample["leakage_ma"], True)
    print("Measurements:", sample)
    print("Protection decision:", result)
    log_event("motor_events.csv", sample, result)
