import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import unittest
from motor_guard import evaluate

class MotorGuardTests(unittest.TestCase):
    def test_overload_trip(self):
        self.assertIn("OVERLOAD", evaluate(15, 5, True)["reasons"])
    def test_leakage_trip(self):
        self.assertIn("LEAKAGE_THRESHOLD_EXCEEDED", evaluate(5, 40, True)["reasons"])
    def test_normal_condition(self):
        self.assertFalse(evaluate(5, 5, True)["trip"])

if __name__ == "__main__":
    unittest.main()
