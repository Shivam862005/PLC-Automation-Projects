# Electrical Engineering Toolkit

A command-line toolkit for common engineering admin tasks: Ohm's law, three-phase power, IPv4 validation and a simple equipment inventory CSV.

## Run
```bash
python src/ee_toolkit.py
python -m unittest discover -s tests
```
