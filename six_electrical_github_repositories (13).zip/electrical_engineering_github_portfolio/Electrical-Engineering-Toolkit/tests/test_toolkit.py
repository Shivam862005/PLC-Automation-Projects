import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import unittest
from ee_toolkit import ohms_law, validate_ipv4

class ToolkitTests(unittest.TestCase):
    def test_ohms_law(self):
        self.assertEqual(ohms_law(voltage=24, resistance=12)["current_a"], 2)
    def test_ip_validation(self):
        self.assertEqual(validate_ipv4("192.168.0.1"), "192.168.0.1")
    def test_invalid_ip(self):
        with self.assertRaises(ValueError):
            validate_ipv4("999.1.1.1")

if __name__ == "__main__":
    unittest.main()
