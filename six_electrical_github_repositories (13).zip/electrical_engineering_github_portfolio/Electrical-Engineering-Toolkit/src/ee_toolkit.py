"""Small standard-library electrical engineering utilities."""
import ipaddress
import csv
from pathlib import Path

def ohms_law(voltage=None, current=None, resistance=None):
    supplied = sum(x is not None for x in (voltage, current, resistance))
    if supplied != 2:
        raise ValueError("Provide exactly two of voltage, current, resistance")
    if voltage is None:
        voltage = current * resistance
    elif current is None:
        if resistance == 0: raise ValueError("Resistance cannot be zero")
        current = voltage / resistance
    else:
        if current == 0: raise ValueError("Current cannot be zero")
        resistance = voltage / current
    return {"voltage_v": voltage, "current_a": current, "resistance_ohm": resistance}

def validate_ipv4(address):
    return str(ipaddress.IPv4Address(address))

def add_inventory_item(path, item_id, name, location, status="Available"):
    path = Path(path)
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(["item_id", "name", "location", "status"])
        writer.writerow([item_id, name, location, status])

if __name__ == "__main__":
    print("Ohm's law:", ohms_law(voltage=24, resistance=12))
    print("Validated IPv4:", validate_ipv4("192.168.1.10"))
    add_inventory_item("equipment_inventory.csv", "EQ-001", "Digital Multimeter", "Electrical Lab")
    print("Added sample equipment to equipment_inventory.csv")
