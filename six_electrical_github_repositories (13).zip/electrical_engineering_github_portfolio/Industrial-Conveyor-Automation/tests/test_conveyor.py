import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import unittest
from conveyor import Conveyor, Mode

class ConveyorTests(unittest.TestCase):
    def test_start(self):
        c = Conveyor()
        self.assertEqual(c.update(start=True), Mode.RUN)
    def test_jam_fault(self):
        c = Conveyor()
        self.assertEqual(c.update(jam=True), Mode.FAULT)
    def test_stop(self):
        c = Conveyor()
        c.update(start=True)
        self.assertEqual(c.update(stop=True), Mode.IDLE)

if __name__ == "__main__":
    unittest.main()
