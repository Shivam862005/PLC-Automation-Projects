from enum import Enum
class Mode(Enum):
    IDLE = "IDLE"
    RUN = "RUN"
    COMPLETE = "COMPLETE"
    FAULT = "FAULT"

class Conveyor:
    def __init__(self, max_travel_scans=5):
        self.mode = Mode.IDLE
        self.scans = 0
        self.max_travel_scans = max_travel_scans

    def update(self, start=False, stop=False, part_detected=False, jam=False, reset=False):
        if jam or (self.mode == Mode.RUN and self.scans >= self.max_travel_scans):
            self.mode = Mode.FAULT
        elif self.mode == Mode.FAULT:
            if reset and not jam:
                self.mode, self.scans = Mode.IDLE, 0
        elif stop:
            self.mode, self.scans = Mode.IDLE, 0
        elif self.mode == Mode.IDLE and start:
            self.mode, self.scans = Mode.RUN, 0
        elif self.mode == Mode.RUN:
            self.scans += 1
            if part_detected:
                self.mode = Mode.COMPLETE
        elif self.mode == Mode.COMPLETE and start:
            self.mode, self.scans = Mode.RUN, 0
        return self.mode

if __name__ == "__main__":
    c = Conveyor()
    for inputs in ({"start": True}, {}, {"part_detected": True}, {"start": True}, {"jam": True}):
        print(inputs, "=>", c.update(**inputs).value)
