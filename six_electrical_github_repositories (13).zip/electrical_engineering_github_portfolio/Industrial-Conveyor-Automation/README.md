# Industrial Conveyor Automation

A state-machine simulation of a simple conveyor with start/stop, part detection, jam timeout and fault reset. Includes a sample sequence and tests.

## Run
```bash
python src/conveyor.py
python -m unittest discover -s tests
```

This is a software learning model, not a validated machine-control or safety system.
