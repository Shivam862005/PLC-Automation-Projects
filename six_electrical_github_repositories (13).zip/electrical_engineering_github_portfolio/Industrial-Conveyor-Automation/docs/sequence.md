# Sequence of Operation

1. Operator requests START.
2. Controller checks permissives and enters RUN.
3. Conveyor advances while monitoring the part sensor.
4. Part detection moves the sequence to COMPLETE.
5. STOP returns the sequence to IDLE.
6. Jam or travel timeout moves the sequence to FAULT.
7. Reset is accepted only after the jam input clears.

Real equipment needs guarding, risk assessment, safety-rated stopping and validated restart behavior.
