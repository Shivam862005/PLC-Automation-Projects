# Electrical Power System Studies

A compact Python toolkit for introductory three-phase calculations and balanced fault estimation. Assumptions are stated in the code; verify results independently before engineering use.

## Run
```bash
python src/power_system.py
```
