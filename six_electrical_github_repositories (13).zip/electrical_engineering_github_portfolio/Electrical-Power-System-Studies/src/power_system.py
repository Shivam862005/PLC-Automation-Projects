"""Introductory balanced three-phase power calculations."""
import math

def three_phase_power_kw(line_voltage_v, line_current_a, power_factor):
    if line_voltage_v < 0 or line_current_a < 0 or not 0 <= power_factor <= 1:
        raise ValueError("Use non-negative voltage/current and PF from 0 to 1")
    return math.sqrt(3) * line_voltage_v * line_current_a * power_factor / 1000

def three_phase_apparent_power_kva(line_voltage_v, line_current_a):
    if line_voltage_v < 0 or line_current_a < 0:
        raise ValueError("Voltage and current must be non-negative")
    return math.sqrt(3) * line_voltage_v * line_current_a / 1000

def balanced_three_phase_fault_current_a(line_voltage_v, impedance_ohm):
    """Bolted 3-phase fault estimate using Thevenin impedance magnitude."""
    if line_voltage_v < 0 or impedance_ohm <= 0:
        raise ValueError("Voltage must be non-negative and impedance positive")
    return line_voltage_v / (math.sqrt(3) * impedance_ohm)

if __name__ == "__main__":
    print(f"Active power: {three_phase_power_kw(415, 10, 0.85):.2f} kW")
    print(f"Apparent power: {three_phase_apparent_power_kva(415, 10):.2f} kVA")
    print(f"3-phase fault current: {balanced_three_phase_fault_current_a(11000, 1.2):.1f} A")
