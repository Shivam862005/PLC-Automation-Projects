# Formula Sheet

For a balanced three-phase system:
- Active power: P = √3 × V_L × I_L × cosφ
- Apparent power: S = √3 × V_L × I_L
- Approximate balanced three-phase fault current: I_sc = V_L / (√3 × |Z_th|)

Use consistent SI units. Fault calculations in real networks require correct sequence networks, source and transformer impedances, grounding assumptions, and applicable standards.
